<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
        <link rel="stylesheet" type="text/css" href="css/index.css">
    </head>
    <body>
        
        <footer>
            <div class="column">
               <h3>SARL T-EXPRESS</h3>
                    <p>75 boulevard de fontainebleu</p>
                    <p>91100 Corbeil Essonnes</p>
                    <p>RCS Evry 83233296900027</p>
                    <p>t.express.idf@mail.fr</a></p>  <!--inserer logo gmail-->
                    <p>01 75 29 38 33 / 07 62 20 42 55 / 06 68 65 68 80</p>        
            </div>
            <div class="column">
                <h3>AIDE</h3>
                    <p><a href="inscription.php">Créer un compte ?</a></p>
                    <p><a href="contact.php">Nous contacter ?</a></p>
                    <p><a href="mailto:t.express.idf@gmail.fr">Postuler en ligne</a></p>
                    <p><a href="apropos.php">Qui sommes nous ?</a></p>
                    
            </div>
            <div class="column">
                <h3>Réseaux</h3>
                <p>Facebook</p>
                <p>Twitter</p>
                <p>Instagram</p>

            </div>
            <div class="column">
               <h3>INFORMATIONS LEGALES</h3>
                    <p><a href="mentionslegales.html">Mentions légales & Politique de confidentialité</a></p>
                    <p><a href="gestion_cookies.php">Gestion cookies</a></p>
            </div>
            <div class="presentation footer">
                <div class="footer-img">
                    <img
                        src="images/__logo.png" alt="logo" 
                    />
                </div>
                <div class="product-footer">
                    <h1>T-EXPRESS C'EST FAIRE LE BON CHOIX</h1>
                    <p>
                        
                    </p>
                    <!--<button>Voir les spécifications</button>-->
                </div>        
            </div> 
        </footer>
    </body>
</html>


    