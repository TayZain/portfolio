<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/gestion_cookies.css">
	<title></title>
</head>

<body>
	
	<article class="article">
            <div class="presentation gestion_cookies">
                <h1>Gestion des cookies</h1>
                <p>
                    Nous utilisons différents cookies sur le site pour améliorer l’interactivité du site et nos services
                </p>
            </div>
        <aside>
            <div class="container">
              <img
                    src="images/gestion_cookies.jpg" alt="image_cookies"
                />
            </div>
        </aside>
        
    </article>
	    
					
	<main>
		<section>
	    	
			<h3 id="1-quest-ce-quun-cookie-">1. Qu&rsquo;est-ce qu&rsquo;un &ldquo;cookie&rdquo; ?</h3>
			<p>Un &ldquo;cookie&rdquo; est une suite d&rsquo;informations, généralement de petite taille et identifié par un nom, qui peut être transmis à votre navigateur par un site web sur lequel vous vous connectez. Votre navigateur web le conservera pendant une certaine durée, et le renverra au serveur web chaque fois que vous vous y re-connecterez. Les cookies ont de multiples usages : ils peuvent servir à mémoriser votre identifiant client auprès d&rsquo;un site marchand, le contenu courant de votre panier d&rsquo;achat, un identifiant permettant de tracer votre navigation pour des finalités statistiques ou publicitaires, etc.</p>
			<h3 id="2-pourquoi-des-cookies-">2. Pourquoi des cookies ?</h3>
			<p>Lorsque vous naviguez sur notre site, des informations relatives à votre navigation sont susceptibles d&rsquo;être enregistrées dans des fichiers « Cookies » déposés sur votre ordinateur, tablette numérique ou smartphone.</p>
			<ul>
				<li>
					D&rsquo;afficher, lors de votre première visite, le bandeau signalant la présence de cookies et la faculté que vous avez de les accepter ou de les refuser.
				</li>
				<li>
					D’établir des mesures statistiques de fréquentation et d&rsquo;utilisation du site en vue d’adapter le site aux demandes de ses visiteurs : nombre de visites sur le «www.journal-officiel.gouv.fr» et de ses rubriques, nombre de pages vues, les pages visitées.</li>
				</ul>
			<p>2 types de cookies sont déposés sur le site journal officiel :</p>
			<h4 id="21-cookies-internes-nécessaires-au-site-pour-fonctionner">2.1 Cookies internes nécessaires au site pour fonctionner</h4>
			<p>Ces cookies permettent au site de fonctionner de manière optimale. Vous pouvez vous y opposer et les supprimer en utilisant les paramètres de votre navigateur, cependant votre expérience utilisateur risque d’être dégradée.</p>
			<br/>
			<h5 id="22-cookies-tiers-destinés-à-améliorer-linteractivité-du-site">2.2 Cookies tiers destinés à améliorer l’interactivité du site.</h5>
			<br/>
			<p>L&rsquo;outil de mesure d&rsquo;audience At Internet (Xiti) est déployé sur ce site afin d&rsquo;obtenir des informations sur la navigation des visiteurs et d&rsquo;en améliorer l’usage.</p>
			<p>L‘autorité française de protection des données (CNIL) a accordé une exemption au cookie Web Analytics d’AT Internet.
			Cet outil est ainsi dispensé du recueil du consentement de l&rsquo;internaute en ce qui concerne le dépôt des cookies analytics.
			Cependant AT Internet permet d’exclure les données de votre navigation par activation de leur option opt-out : <a href="http://www.xiti.com/fr/optout.aspx">gérer les préférences opt-out AT Internet</a></p>
			<p>Pour en savoir plus sur la gestion des cookies de statistiques d&rsquo;AT Internet :
			<a href="http://www.atinternet.com/politique-du-respect-de-la-vie-privee">www.atinternet.com/politique-du-respect-de-la-vie-privee</a>
			<a href="https://www.atinternet.com/societe/rgpd-et-vie-privee/">https://www.atinternet.com/societe/rgpd-et-vie-privee/</a></p>
			<p><strong>À savoir :</strong></p>
			<ul>
				<li>Les données collectées ne sont pas recoupées avec d&rsquo;autres traitements</li>
				<li>Le cookie déposé sert uniquement à la production de statistiques anonymes</li>
				<li>Le cookie ne permet pas de suivre la navigation de l&rsquo;internaute sur d&rsquo;autres sites.</li>
			</ul>
			<p>
				Vous pouvez paramétrer votre navigateur afin qu&rsquo;il vous signale la présence de cookies et vous propose de les accepter ou non. Vous pouvez accepter ou refuser les cookies au cas par cas ou bien les refuser une fois pour toutes. Il est rappelé que ce paramétrage est susceptible de modifier vos conditions d&rsquo;accès aux services du site nécessitant l&rsquo;utilisation de cookies.
				Le paramétrage des cookies est différent pour chaque navigateur et en général décrit dans les menus d&rsquo;aide.</p>
			<br/>
			<h3 id="3-comment-supprimer-les-cookies-">3. Comment supprimer les cookies ?</h3>
			<p>
				Vous pouvez désactiver les cookies. Votre navigateur peut également être paramétré pour vous signaler les cookies qui sont déposés dans votre ordinateur et vous demander de les accepter ou non. Vous pouvez accepter ou refuser les cookies au cas par cas ou bien les refuser systématiquement une fois pour toutes. Nous vous rappelons que le paramétrage est susceptible de modifier vos conditions d&rsquo;accès à nos services nécessitant l&rsquo;utilisation de cookies.
			</p>
			<p>
				La configuration de chaque navigateur est différente. Elle est décrite dans le menu d&rsquo;aide de votre navigateur, qui vous permettra de savoir de quelle manière modifier vos souhaits en matière de cookies. Vous pouvez désactiver les cookies en suivant les instructions comme suit :
			</p>
			<h4 id="31-internet-explorer">3.1. Internet Explorer</h4>
				<ul>
					<li>Dans Internet Explorer, cliquez sur le bouton « Outils », puis sur « Options Internet ».</li>
					<li>Sous l&rsquo;onglet « Général », sous « Historique de navigation », cliquez sur « Paramètres ».</li>
					<li>Cliquez sur le bouton « Afficher les fichiers ».</li>
					<li>Cliquez sur l&rsquo;en-tête de colonne « Nom » pour trier tous les fichiers dans l&rsquo;ordre alphabétique, puis parcourez la liste jusqu&rsquo;	à ce que vous trouviez des fichiers commençant par le préfixe « Cookie » (tous les cookies possèdent ce préfixe et contiennent habituellement le 	nom du site Web qui a créé le cookie).</li>
					<li>Sélectionnez-le ou les cookies comprenant le nom « journal-officiel.gouv.fr » et supprimez-les.</li>
					<li>Fermez la fenêtre qui contient la liste des fichiers, puis cliquez deux fois sur OK pour retourner dans Internet Explorer.</li>
				</ul>
			<p>Précisions, actualisation : consultez la page d’aide d&rsquo;Internet Explorer.</p>
			<h4 id="32-firefox">3.2. Firefox</h4>
				<ul>
					<li>Allez dans l&rsquo;onglet « Outils »  du navigateur, puis sélectionnez le menu « Options ».</li>
					<li>Dans la fenêtre qui s&rsquo;affiche, choisissez « Vie privée » et cliquez sur « Affichez les cookies ».</li>
					<li>Dans la fenêtre qui s&rsquo;affiche, choisissez « Vie privée » et cliquez sur « Affichez les cookies ».</li>
					<li>Repérez les fichiers qui contiennent le nom « journal-officiel.gouv.fr ». Sélectionnez-les et supprimez-les.</li>
				</ul>
			<p>Précisions, actualisation : consultez la page d’aide de Firefox.</p>
			<h4 id="33-safari">3.3. Safari</h4>
				<ul>
					<li>Dans votre navigateur, choisissez le menu « Édition &gt; Préférences ».</li>
					<li>Cliquez sur « Sécurité ».</li>
					<li>Cliquez sur « Afficher les cookies ».</li>
					<li>Sélectionnez les cookies qui contiennent le nom « journal-officiel.gouv.fr » et cliquez sur « Effacer » ou sur « Tout effacer ».</li>
					<li>Après avoir supprimé les cookies, cliquez sur « Terminé ».</li>
				</ul>
			<p>Précisions, actualisation : consultez la page d’aide de Safari.</p>
			<h4 id="34-google-chrome">3.4. Google Chrome</h4>
				<ul>
					<li>Cliquez sur l&rsquo;icône du menu « Outils ».</li>
					<li>Sélectionnez « Options ».</li>
					<li>Cliquez sur l&rsquo;onglet « Options avancées » et accédez à la section « Confidentialité ».</li>
					<li>Cliquez sur le bouton « Afficher les cookies ».</li>
					<li>Repérez les fichiers qui contiennent le nom « journal-officiel.gouv.fr ». Sélectionnez-les et supprimez-les.</li>
					<li>Cliquez sur « Fermer » pour revenir à votre navigateur.</li>
				</ul>
			<p>Précisions, actualisation : consultez la page d’aide de Chrome.</p>
			<ul>
				<li><a href="https://support.google.com/chrome/answer/95647?hl=fr&amp;hlrm=en">https://support.google.com/chrome/answer/95647?hl=fr&amp;hlrm=en</a></li>
				<li><a href="https://policies.google.com/technologies/ads?hl=fr">https://policies.google.com/technologies/ads?hl=fr</a></li>
			</ul>
			<h4 id="35-opera">3.5. Opera</h4>
			<p>Précisions, actualisation : consultez la page d’aide d&rsquo;Opera.</p>
			<ul>
				<li><a href="https://help.opera.com/en/latest/web-preferences/">https://help.opera.com/en/latest/web-preferences/</a></li>
			</ul>
	    </section>
	</main>
			
	</body>
</html>