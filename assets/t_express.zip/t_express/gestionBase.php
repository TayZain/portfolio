<?php

function gestionnaireDeConnexion() {
    try {
        $pdo = new PDO(
                'mysql:host=localhost;dbname=tholdi',
                'root', '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
        );
    } catch (PDOException $err) {
        var_dump($err);
        die;
    }
    return $pdo;
}


function obtenirVille() {
    $pdo = gestionnaireDeConnexion();
    $req = "select * from ville";
    $pdoStatement = $pdo->query($req);
    $lesVilles = $pdoStatement->fetchAll(PDO::FETCH_ASSOC);
    return $lesVilles;
}

function obtenirPays() {
    $pdo = gestionnaireDeConnexion();
    $req = "select * from pays";
    $pdoStatement = $pdo->query($req);
    $lesPays = $pdoStatement->fetchAll(PDO::FETCH_ASSOC);
    return $lesPays;
}

function obtenirTypeContainer() {
    $pdo = gestionnaireDeConnexion();
    $req = "select * from typeContainer ";
    $pdoStatement = $pdo->query($req);
    $lesContainers = $pdoStatement->fetchAll(PDO::FETCH_ASSOC);
    return $lesContainers;
}

function ajouterUneReservation($dateDebutReservation, $dateFinReservation,$dateReservation, $volumeEstime, $codeVilleMiseDisposition, $codeVilleRendre, $codeUtilisateur,$etat) {

    $pdo = gestionnaireDeConnexion() ;
    $dateReservation = time();
    $dateDebutReservation = strtotime($dateDebutReservation);
    $dateFinReservation = strtotime($dateFinReservation);
    $req = "insert into reservation"
            . " (dateDebutReservation,dateFinReservation,dateReservation,"
            . " volumeEstime,codeVilleMiseDisposition,"
            . " codeVilleRendre,codeUtilisateur,etat)"
            . " values ($dateDebutReservation,$dateFinReservation,$dateReservation
                        ,$volumeEstime,$codeVilleMiseDisposition,$codeVilleRendre,"
            . "$codeUtilisateur,'EnCours')";
    $pdo->exec($req);
    $lastInsertId = $pdo->lastInsertId();
    return $lastInsertId;
}

function ajouterLigneDeReservation($codeReservation,$numTypeContainer,$quantite){
    $pdo = gestionnaireDeConnexion();
    $req = "insert into reserver (codeReservation,numTypeContainer,quantite) "
            . " values ($codeReservation,$numTypeContainer,$quantite)" ;
    $pdo->exec($req);
}


function ajouterUnUtilisateur($raisonSociale,$adresse,$cp,$ville,$adrMel,$telephone,$contact,$codePays,$login,$mdp) {

    $pdo = gestionnaireDeConnexion() ;
    $req = "insert into utilisateur"
            . " (codeUtilisateur,raisonSociale, adresse, cp, ville, adrMel, telephone, contact,codePays,login, mdp)"
            . " values ('','$raisonSociale','$adresse','$cp','$ville','$adrMel','$telephone','$contact','$codePays','$login','$mdp')";
    $pdo->exec($req);
    $lastInsertId = $pdo->lastInsertId();
    return $lastInsertId ;
}


function consultationReservation(){
    $consultation  = array();
    $pdo = gestionnaireDeConnexion();
    if ($pdo != NULL) {
    $req = "Select * from reservation order by codeReservation DESC limit 1";
    $pdoStatement = $pdo->query($req);
    $consultation = $pdoStatement->fetchAll(PDO::FETCH_ASSOC);
    }
    return $consultation;
}


function verification($login, $mdp) {
    $compteExistant = false;
    $pdo = gestionnaireDeConnexion();
    $sql = "SELECT * ,count(*) as nb FROM utilisateur "
        . " WHERE login=:login AND mdp=:mdp";
    $prep = $pdo->prepare($sql);

    $prep->bindParam(':login', $login, PDO::PARAM_STR);
    $prep->bindParam(':mdp', $mdp, PDO::PARAM_STR);

    $prep->execute();
    $resultat = $prep->fetch();

    if ($resultat["nb"] == 1) {
        $compteExistant = true;
    }
    $prep->closeCursor();

    return $compteExistant;
}

function majuscule($login){
    $pdo = gestionnaireDeConnexion();
    $req = "SELECT login,UPPER(login) FROM utilisateur";
    $pdo->exec($req);
}

//functions sami 


function gestionnaireDeConnexion() 
{
    try {
        $pdo = new PDO(
                'mysql:host=localhost;dbname=yoro','root', '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
        );
    } catch (PDOException $erreur) 
    {
        var_dump($erreur);
        die;
    }
    return $pdo;
}

function ajouterUtilisateur($nom, $prenom, $adrMel, $numTel, $login, $mdp){
    $pdo = gestionnaireDeConnexion();
    
    $requetePreparee = "INSERT INTO utilisateur (nom, prenom, adrMel, numTel, login, mdp) VALUES (:nom, :prenom, :adrMel, :numTel, :login, :mdp)";
    $requete = $pdo->prepare($requetePreparee);
    
    $requete->execute([
        'nom' => $nom,
        'prenom' => $prenom,
        'adrMel' => $adrMel,
        'numTel' => $numTel,
        'login' => $login,
        'mdp' => $mdp
    ]);
    $insert = $requete->fetchAll();
}



function emailValide($adrMel)
{
    if(filter_var($adrMel, FILTER_VALIDATE_EMAIL))
    {
       return true;
    }
    else
    {
        return false;
    }
}

function checkUser($login)
{ 
    $carSpeciaux = "&é(-è_çà)°=+^£*µù%!§:/;.,?"; // Caractères spéciaux
    $tabCarSpecial = str_split($carSpeciaux); // Je transforme ma chaine de caractère en tableau que j'appelle tabCarSpecial prenant comme indice un seul caractère.
    $carNumerique = "0123456789";  // Caractères numériques.
    $tabCarNumerique = str_split($carNumerique);
    $lenLogin = strlen($login);
    
    if ($lenLogin < 3  || empty($lenLogin ))
    {
        echo "Le nom d utilisateur $login doit contenir au moins 3 caractères <br>";
        return false;
    }
    else 
    {
       return true;
    }
}

function checkMdpDouzeCaracteres($mdp)
{      
    $carSpeciaux = "&é(-è_çà)°=+^£*µù%!§:/;.,?";
    $tabCarSpecial = str_split($carSpeciaux);
    $carNumerique = "0123456789"; 
    $tabCarNumerique = str_split($carNumerique);
    $lenMdp = strlen($mdp);
    
    if ($lenMdp < 12)
    {
        echo "Le mot de passe doit contenir au moins 12 caractères <br>";
        return false;
    }
    else
    {
        return true;
    }
}

function checkMdpCarSpeciaux($mdp)
{ 
    $carSpeciaux = "&é(-è_çà)°=+^£*µù%!§:/;.,?";
    $tabCarSpecial = str_split($carSpeciaux);
    $carNumerique = "0123456789"; 
    $tabCarNumerique = str_split($carNumerique);
    $tabMdp = str_split($mdp);
    $commun = array_intersect($tabMdp, $tabCarSpecial);

    if (array_intersect($tabMdp, $tabCarSpecial)) 
        {
            return true;
        }
    else
        {
            echo "Le mot de passe $mdp ne contient pas de caractère spéciale. <br>";
            return false;
        }
}


function checkMdpAlphaNumerique($mdp)
{ 
    $carSpeciaux = "&é(-è_çà)°=+^£*µù%!§:/;.,?";
    $tabCarSpecial = str_split($carSpeciaux);
    $carNumerique = "0123456789"; 
    $tabCarNumerique = str_split($carNumerique);
    $tabMdp = str_split($mdp);
    $commun = array_intersect($tabMdp, $tabCarSpecial);
    $commun = array_intersect($tabMdp, $tabCarNumerique);

    if (array_intersect($tabMdp, $tabCarNumerique)) 
    {
       return true;
    }
    else
    {
        echo "Le mot de passe $mdp ne contient pas de caractère numérique. <br>";
        return false;
    }
}

function checkMdpMaj($mdp){
    
    $carSpeciaux = "&é(-è_çà)°=+^£*µù%!§:/;.,?";
    $tabCarSpecial = str_split($carSpeciaux);
    $carNumerique = "0123456789"; 
    $tabCarNumerique = str_split($carNumerique);
    $tabMdp = str_split($mdp);
    $commun = array_intersect($tabMdp, $tabCarSpecial);
    $mdp = implode($tabMdp);
    
    if(preg_match('/[A-Z]/', $mdp))
    {
        return true;
    }
    else
    {
        echo "Il faut au minimum une majuscule au mot de passe. <br>";
        return false;
    }
}


function checkMdpMin($mdp)
{
    $carSpeciaux = "&é(-è_çà)°=+^£*µù%!§:/;.,?";
    $tabCarSpecial = str_split($carSpeciaux);
    $carNumerique = "0123456789"; 
    $tabCarNumerique = str_split($carNumerique);
    $tabMdp = str_split($mdp);
    $commun = array_intersect($tabMdp, $tabCarSpecial);
    $mdp = implode($tabMdp);

    if(preg_match('/[a-z]/', $mdp))
    {
        return true;
    }
    else
    {
       return false;
       echo "Il faut au minimum une minuscule au mot de passe";
    }
}

function checkNum($numTel)
{ 
    if(preg_match("#[0][6][- \.?]?([0-9][0-9][- \.?]?){4}$#", $numTel))
    {
        return true;
    }
    else
    {
       return false;
    }
}

?>
