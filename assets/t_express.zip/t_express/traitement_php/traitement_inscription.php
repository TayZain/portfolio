<?php
    include_once '_gestionBase.inc.php';
           
           
$nom = htmlspecialchars($_POST['nom']);
$prenom = htmlspecialchars($_POST['prenom']);
$adrMel = htmlspecialchars($_POST['adrMel']);
$numTel = htmlspecialchars($_POST['numTel']);
$login = htmlspecialchars($_POST['login']);
$mdp = htmlspecialchars($_POST['mdp']);


checkUser($login);
checkMdpDouzeCaracteres($mdp);
checkMdpCarSpeciaux($mdp);
checkMdpAlphaNumerique($mdp);
checkMdpMaj($mdp);
checkMdpMin($mdp);
emailValide($adrMel);
checkNum($numTel);


if(checkUser($login) && checkMdpDouzeCaracteres($mdp) && checkMdpCarSpeciaux($mdp) . 
   checkMdpAlphaNumerique($mdp) && checkMdpMaj($mdp) && checkMdpMin($mdp) && emailValide($adrMel) && checkNum($numTel)) 
{
    ajouterUtilisateur($nom, $prenom, $adrMel, $numTel, $login, $mdp);
    header("Location: inscription.php?Reussie");
}
else
{ 

}
 

?>