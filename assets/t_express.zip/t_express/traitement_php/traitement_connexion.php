<?php session_start();
include_once 'gestionBase.php';

	$login=$_POST['login'];
	$mdp=$_POST['mdp'];
	

	$test=verification($login, $mdp);  
if($test==true)
{
    $_SESSION['login']=$login;
    $_SESSION['mdp']=$mdp;
}
	
header("location: index.php");
?>