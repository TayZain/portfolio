create table societe(
  id_societe int(20) AUTO_INCREMENT,
  raisonSociale varchar (20) NOT NULL,
  num_fixe_societe char(20) NOT NULL,
  adresse_societe char (40) NOT NULL,
  codePostale decimal (5) NOT NULL,
  primary key ('id_societe'),
)

create table destinataire(
  id_destinataire int(20) AUTO_INCREMENT,
  primary key ('id_societe'),
)
create table expediteur(
  id_expediteur int(20) AUTO_INCREMENT,
  primary key ('id_societe',)

)
create table colis(  /*verifier que les deux clés étrangères sont bien différentes entre id_destinataire et id_expediteur avec un trigger*/
  id_colis int(20) NOT NULL,
  NbTotalUT int(20) NOT NULL,
  NbTotalPalettes decimal(20) NOT NULL,
  NbTotalColis decimal(20) NOT NULL,
  NbTotalRehausse decimal(20) NOT NULL,
  poidsTotalKg double (20) NOT NULL,
  description varchar (20) NOT NULL,
  id_expediteur int(20) NOT NULL,
  id_destinataire int(20) NOT NULL,
  primary key ('id_colis'),
  FOREIGN KEY (id_destinataire) REFERENCES destinataire (id_destinataire),
  FOREIGN KEY (id_expediteur) REFERENCES  expediteur (id_expediteur)
)

create table pays(
  nomPays CHAR (20) default 'FRANCE',
  primary key (`nomPays`)
)engine = innodb ;

/* faire insert des pays avec le code téléphone 

"Pays-Bas" => 31, 

     "Belgique" => 32, 

     "France" => 33, 

     "Espagne" => 34, 
Hongrie" => 36, 

     "Italie" => 39, 
"Suisse" => 41, 

     "Autriche" => 43, 

     "Royaume-Uni" => 44, 
"Allemagne" => 49, 
"Portugal" => 351, 

     "Luxembourg" => 352, 
"Andorre" => 376, 

     "Monaco" => 377, 
"Italie" => 390,  
"france +33 "
*/

create table devis(
  id_devis INT (20) NOT NULL,
  id_colis int (20) NOT NULL,
  primary key (`id_devis`),
  foreign key (id_colis) REFERENCES colis (id_colis)
  ) engine = innodb ;
  



create table utilisateur(
	id_utilisateur int(20) NOT NULL AUTO_INCREMENT, 
	nom_utilisateur varchar(20) NOT NULL,
	prenom_utilisateur varchar(20) NOT NULL,
	mail_utilisateur varchar(30) NOT NULL,
	tel_utilisateur varchar(20) NOT NULL,
    login CHAR (10) NOT NULL,
    mdp CHAR(10) NOT NULL,
    ADD CONSTRAINT CHK_Email CHECK (email like '%_@_%' AND PATINDEX ('%[â-z,Ä-Z,0-9,@,.,_,\-]%')
    primary key (`id_utilisateur`),
    FOREIGN KEY (codePays)REFERENCES pays(codePays)
) engine = innodb;



create table devis(
  codeDevis INT NOT NULL,
  dateDevis bigint(20),
  montantDevis DECIMAL (6,2),
  volume  DECIMAL(4),
  nbContainers DECIMAL (11),
  valider INT (5),
  primary key (`codeDevis`)
  ) engine = innodb ;
  
/*une société passe 0,* commandes*/

create table commande(
  id_commande INT (100) NOT NULL,
  datecommande date NOT NULL,
  datelivraisondemande date NOT NULL,
  id_societe int (20) NOT NULL,
  nomPays char(20) not null default 'FRANCE',
  FOREIGN KEY (nomPays)
  primary key (`codeReservation`),
  FOREIGN KEY (codeUtilisateur) REFERENCES utilisateur(codeUtilisateur),
  FOREIGN KEY (id_societe) REFERENCES societe(id_societe)
) engine = innodb ;



create TRIGGER VerifyPhone
on T_client
instead of insert,update
   as 
    begin
           declare @i smallint,@b smallint,@tel varchar(20) 
           set @tel=(select cli_tel from INSERTED)    
  
           select @b=1
           select @i=1
           while @i<=len(@tel) and @b=1
              begin
                if (ascii(substring(@tel,@i,1))<48 or ascii(substring(@tel,@i,1))>57) and (ascii(substring(@tel,@i,1))<>46)                   
                  select @b=0
                 select @i=@i+1
              end
           if @b=0
               begin
                 ROLLBACK TRANSACTION
                 print 'Transaction annulée'
                 print 'numéro de téléphone Invalide'
               end
           else
               begin
                  if update(cli_tel)
                     delete T_client where cli_id=(select cli_id from deleted)
                  insert T_client select * from INSERTED
               end      
end