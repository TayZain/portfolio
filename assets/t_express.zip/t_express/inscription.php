<?php
session_start();
require_once '_gestionBase.inc.php';
include_once 'navbar.php';
?>

<!DOCTYPE html>
    <html lang="fr">
        <head>
            <meta charset="UTF-8">

            <link rel="stylesheet" href="css/inscription.css" media="screen">

        
            <title>Inscription</title>
        </head>
        <body>
        <center> <div class="div-one">
                <form class="form" action="inscription_traitement.php" method="post">
                    
                        <div class='div-second'>
                            
                    <div class="div-form">
                        <div class='div-sous-form'>
                        <p class='top-p' id='nom-p'>Nom </p>
                            <input class="input" name="nom" type='text' required="Veuillez remplir le champ">
                        </div>
                    </div>
                        
                        <br>
                    <div class="div-form">
                        <div class='div-sous-form'>
                        <p class='top-p' id='prenom-p'>Prenom </p>
                            <input class="input" name="prenom" type='text' required="Veuillez remplir le champ">
                    </div>
                        </div>
                        
                    <br>
                    <div class="div-form">
                        <div class='div-sous-form'>
                        <p class='top-p' id='adr-p'>Adresse Mail </p>
                            <input class="input" name="adrMel" type="text" required="Veuillez remplir le champ">
                    </div>
                        </div>
                    
                    <br>
                    <div class="div-form">
                        <div class='div-sous-form'>
                        <p class='top-p' id='num-p'>Numéro de téléphone </p>
                            <input class="input" name="numTel" type="number" required="Veuillez remplir le champ">
                    </div>
                        </div>
                    
                        <br>
                    <div class="div-form">
                        <div class='div-sous-form'>
                        <p class='top-p' id='utilisateur-p'>Nom d'utilisateur </p>
                            <input class="input" name="login" type="text" required="Veuillez remplir le champ">
                    </div>
                        </div>
                        
                        <br>
                    <div class="div-form">
                        <div class='div-sous-form'>
                        <p class='top-p' id='mdp-p'>Mot de passe </p>
                            <input class="input" name="mdp" type="password" required="Veuillez remplir le champ">
                    </div>
                        </div>
                    
                    <br>
                    <br>
                    <input  class='input' id="button" type="submit" value="S'inscrire">
                    
                        </div>
                </form>
            </div> </center>

        </body>
</html>