<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/apropos.css">
    <title>T-EXPRESS LOGISTIQUE - TRANSPORT</title>
</head>
    
<body>
    <?php include('header.php'); ?>
    
    <article class="article">
            <div class="container apropos">
                <h1>A PROPOS DE T-EXPRESS</h1>
                <p>
                    Nous utilisons différents cookies sur le site pour améliorer l’interactivité du site et nos services
                </p>
            </div>
        <aside>
            <div class="container">
              <img
                    src="images/gestion_cookies.jpg" alt="image_cookies"
                />
            </div>
        </aside>
        
    </article>
</body>
</html>