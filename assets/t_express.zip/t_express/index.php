<?php 
session_start();
include_once 'gestionBase.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>T-EXPRESS LOGISTIQUE - TRANSPORT</title>
</head>
<body>
    <header>
        <nav class="header_nav">
            <div id="titre_principal">
                <div id="logo"><img src="images/__logo.png"><h1>T-Express</h1></div>

                <div class="header_nav">
                    <p><a href="index.php">Accueil</a></p>
                    <p><a href="apropos.php">A propos</a></p>
                    <p><a href="contact.php">Contact</a></p>
                    <p><a href="inscription.php">S'inscrire</a></p>
                    <p><a href="connexion.php">Connexion</a></p>
                    <!--<button>Acheter</button>-->
                </div>
                
            </div>
        </nav>
        <section class="presentation first">
            <div class="product-presentation">
                <h1>Le transport, c'est vivre sa passion</h1>
                <p>
                    Notre force est la rapidité ainsi nous livrons sur le territoire national à jour j et également dans l'ensemble de l'Europe à jour +1 grâce à une équipe expérimentée. 
                </p>
                
            </div>
            <div class="image-presentation">
                <img
                    src="https://www.areas.fr/medias/images/flotte1.png?v=34"
                />
            </div>
        </section>
    </header>
    <main>
         <section class="presentation carte">
            <div class="product-presentation">
                <h1>Livraisons express sur tout le territoire français </h1>
                <p>
                    <ul>
                        <li>Nous garantissant à nos clients une livraison rapide</li>
                        <li>Notre équipe est là pour vous faire avancer sans stress</li>
                        <li>Toutes nos livraisons sont fiables et sans failles</li>

                    </ul> 
                </p>
                <!--<button>Voir les spécifications</button>-->
            </div>
            <div class="image-presentation">
                <img
                    src="images/carte_france.jpeg" alt="carte_fr"
                />
            </div>
            
        </section>
        <section class="presentation second">
            <div class="image-presentation">
                <img
                    src="https://www.syndicatdupneu.org/wp-content/uploads/2020/04/poids-lourd@0.75x.png"
                />
            </div>
            <div class="product-presentation">
                <h1>Le nouveau transport T-Express</h1>
                <p>
                    T-EXPRESS, est spécialisée dans la livraison express. Nous proposons des services adaptés afin de répondre aux besoins et attentes de tous nos clients. 
                </p>
                <!--<button>Voir les spécifications</button>-->
            </div>
            
        </section>
        <section class="presentation fourth">
            <div class="product-presentation">
                <h1>Notre passion c'est votre plaisir</h1>
                <p>
                    T-EXPRESS vous accompagne au quotidien, pour cela toutes nos livraisons sont fiables et assurées à 100% sans faille avec un grand professionnalisme.  
                </p>
                <!--<button>Voir les spécifications</button>-->
            </div>
            <div class="image-presentation">
                <img
                    src="images/image_route.jfif" alt="image"
                />
            </div>   
        </section>
        <section class="presentation third">
            <div class="product-presentation">
                <h1>PLUSIEURS EQUIPES NOUS FONT CONFIANCES</h1>
                <p>
                    Notre champ de livraison est varié aéronatique, médical, pharmaceutique et encore automotive. Grâce à notre expérience et savoir-faire, nous comptons à ce jour dans nos clients : Safran, Sncf et aussi Petnet pharmaceutique. Parmi nos partenariats nous comptons Warning et Geodis.
                </p>
                <div class="small-images">
                        <div class="small">
                            <img
                                src="images/logo_safran.png"
                            />
                        </div>
                        <div class="small">
                            <img
                                src="images/logo_sncf.png" alt="logo_sncf"
                            />
                        </div>
                        <div class="small">
                            <img
                                src="images/logo_petnet.jpg" alt="logo_petnet"
                            />
                        </div>
                        <div class="small">
                            <img
                                src="images/logo_warning.jpg" alt="logo_warning"
                            />
                        </div>
                        <div class="small">
                            <img
                                src="images/logo_geodis.jpg" alt="logo_geodis"
                            />
                        </div>
                </div>
                <!--<button>Voir les spécifications</button>-->
            </div>     
        </section>

    </main> 
    <?php include('footer.php'); ?>
</body>
</html>