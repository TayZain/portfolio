<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/contact.css" >
    <title>T-EXPRESS CONTACT</title>
</head>
<body>
    <?php include('header.php'); ?>
    <main>
        <article>
            <div class="contacter first">
                <div class="product_presentation">
                     <h1>Nous Contacter</h1>
                    <p>Si vous avez besoin d'un conseil ou renseignement, contactez nous en remplissant le formulaire ci-dessous</p>
                </div>
            </div>
            <aside>
                <div class="container">
                  <h1>Formulaire de contact</h1>
                  <form action="traitement_php/traitement_contact.php" method="POST">
                    <label for="fname">Nom & prénom</label>
                    <input type="text" id="fname" name="firstname" placeholder="Votre nom et prénom" required>

                    <label for="sujet">Sujet</label>                       
                    <input type="text" id="sujet" name="sujet" placeholder="L'objet de votre message" required>
                   
                    

                    <label for="emailAddress">Email</label>
                    <input id="emailAddress" type="email" name="email" placeholder="Votre email" required>


                    <label for="subject">Message</label>
                    <textarea id="subject" name="subject" placeholder="Votre message" style="height:200px" required></textarea>

                    <input type="submit" value="Envoyer">
                  </form>
                </div>
            </aside>
        
        </article>
        
        <section>
            <div class="presentation second">
                <div class="product_presentation">
                    <h1>Service client</h1>
                    <p>Vous avez besoin de conseils sur un produit, un service ou une destination. Vous souhaitez obtenir des informations sur un colis.</p>
                    <p>Vous pouvez nous joindre :<br> </p>
                    <p>Que vous soyez un particulier ou une entreprise:</p>
                    <ul>
                        <ol><strong>Nous sommes disponibles 24h/24 et 7j/7 <br> </strong>
                            <li>Par téléphone:</li>
                                <ol><a href="tel:+3317529">01 75 29 38 33</a></ol>
                                <ol><a href="tel:+33762204255">07 62 20 42 55</a></ol>
                                <ol><a href="tel:+33668656880">06 68 65 68 80</a></ol>
                            <li>Par adresse mail:</li>
                                <ol><a href="mailto:t.express.idf@gmail.fr">t.express.idf@mail.fr</a></ol>
                        </ol>
                    </ul>
                </div>
            </div>
        </section>
    </main>
    <?php include('footer.php'); ?>
</body>
</html>



