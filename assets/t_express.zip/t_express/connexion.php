<!DOCTYPE html>
    <head>
       <meta charset="utf-8">
        <!-- importer le fichier de style -->
        <link rel="stylesheet" href="css/connexion.css" media="screen" type="text/css" />
        <title>Connexion T-EXPRESS</title>
    </head>
    <body>
        <?php include('header.php'); ?>
        <div id="container">
            <!-- zone de connexion -->
            
            <form action="traitement_connexion.php" method="POST">
                <h1>Connexion</h1>
                
                <label><b>Login utilisateur</b></label>
                <input type="text" placeholder="Entrer le login" name="username" required>

                <label><b>Mot de passe</b></label>
                <input type="password" placeholder="Entrer le mot de passe" name="password" required>

                <input type="submit" id='submit' value='LOGIN' >
                <div class="signup-link">
                        Pas de compte ? <a href="Inscription.php">Inscrie-toi</a>
                    </div>
                <div class="signup-link">
                        Mot de passe oublié ? <a href="Inscription.php">Inscrie-toi</a>
                    </div>
            </form>
        </div>
        <?php include('footer.php') ; ?>
    </body>
</html>


// Page traitement de connexion 

<?php session_start();
include_once 'gestionBase.php';

    $login=$_POST['login'];
    $mdp=$_POST['mdp'];
    

    $test=verification($login, $mdp);  
    if($test==true)
    {
        $_SESSION['login']=$login;
        $_SESSION['mdp']=$mdp;
    }
    
header("location: index.php");
?>