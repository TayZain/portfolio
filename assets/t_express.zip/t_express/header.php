<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
        <link rel="stylesheet" type="text/css" href="css/index.css" >
    </head>
    <body>
        <header>
            <nav class="header_nav">
                <div id="titre_principal">
                    <div id="logo"><img src="images/__logo.png"><h1>T-Express</h1></div>

                    <div class="header_nav">
                        <p><a href="index.php">Accueil</a></p>
                        <p><a href="apropos.html">A propos</a></p>
                        <p><a href="contact.php">Contact</a></p>
                        <p><a href="inscription.html">S'inscrire</a></p>
                        <p><a href="connexion.php">Connexion</a></p>
                        <!--<button>Acheter</button>-->
                    </div>        
                </div>
            </nav>
        </header>
    </body>
</html>